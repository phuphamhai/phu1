const chrome=globalThis.chrome;export{chrome};
