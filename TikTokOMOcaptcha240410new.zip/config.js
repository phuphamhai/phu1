var API_TOKEN = "apitokenlco9ugecbypu8agr6rbxjh2sefw7atcw5vot3mgtaptvauv8wbtjzeo6h45noq1711861845"; // Api token trên web
const DELAY_CLICK = 500; // Khoảng cách click
const DELAY_SWIPE = 15; // Số càng lớn kéo càng chậm
const LOOP = true; // Để true sẽ giải đến khi thành công